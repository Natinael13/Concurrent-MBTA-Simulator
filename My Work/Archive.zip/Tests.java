import static org.junit.Assert.*;
import org.junit.*;

import java.util.ArrayList;
import java.util.List;

public class Tests {
  @Test public void testPass() {

    MBTA mbta = new MBTA();
    mbta.addLine("red", List.of("s1", "s2", "s3", "s4", "s5", "s6"));
    mbta.addJourney("passenger1", List.of("s2", "s3"));
    Log log = new Log();

    Train red = Train.make("red");
    Passenger passenger1 = Passenger.make("passenger1");
    Station s_1= Station.make("s1");
    Station s_2= Station.make("s2");
    Station s_3= Station.make("s3");
    Station s_4= Station.make("s4");
    Station s_5= Station.make("s5");
    Station s_6= Station.make("s6");




    log.train_moves(red, s_1, s_2);
    log.passenger_boards(passenger1, red, s_2);
    log.train_moves(red, s_2, s_3);
    log.passenger_deboards(passenger1, red, s_3);
    log.train_moves(red, s_3, s_4);
    log.train_moves(red, s_4, s_5);
    log.train_moves(red, s_5, s_6);

    Verify.verify(mbta, log);
    mbta.checkEnd();
  }


}
