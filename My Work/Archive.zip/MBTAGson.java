import java.util.HashMap;
import java.util.List;

public class MBTAGson {

    public HashMap<String, List<String>> lines = new HashMap<>();
    public HashMap<String, List<String>> trips = new HashMap<>();

}
